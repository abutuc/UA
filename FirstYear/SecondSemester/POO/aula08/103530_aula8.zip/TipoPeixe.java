public enum TipoPeixe {
    CONGELADO, FRESCO, DESCONHECIDO
}
