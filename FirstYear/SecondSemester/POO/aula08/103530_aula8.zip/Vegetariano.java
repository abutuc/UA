public interface Vegetariano {
    
}
