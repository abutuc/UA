public class test {
    
    public static void main(String[] args){
        int[] livros = new int[3];
        System.out.println(livros[0]);
    }
}
